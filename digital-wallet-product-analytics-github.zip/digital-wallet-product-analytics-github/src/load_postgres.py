from __future__ import annotations

import os
from pathlib import Path

import pandas as pd
from dotenv import load_dotenv
from sqlalchemy import URL, create_engine, inspect, text


PROJECT_ROOT = Path(__file__).resolve().parents[1]
load_dotenv(PROJECT_ROOT / ".env")

DATA_PATH = PROJECT_ROOT / "data" / "processed" / "digital_wallet_customer_segments.csv"
VIEW_SQL_PATH = PROJECT_ROOT / "sql" / "02_create_retention_queue_view.sql"


def create_db_engine():
    required = ["PGUSER", "PGPASSWORD", "PGDATABASE"]
    missing = [name for name in required if not os.getenv(name)]
    if missing:
        raise RuntimeError(
            f"Missing environment variables: {', '.join(missing)}. "
            "Copy .env.example and configure PostgreSQL credentials."
        )

    url = URL.create(
        drivername="postgresql+psycopg2",
        username=os.environ["PGUSER"],
        password=os.environ["PGPASSWORD"],
        host=os.getenv("PGHOST", "localhost"),
        port=int(os.getenv("PGPORT", "5432")),
        database=os.environ["PGDATABASE"],
    )
    return create_engine(url)


def main() -> None:
    if not DATA_PATH.exists():
        raise FileNotFoundError(
            f"Processed dataset not found: {DATA_PATH}\n"
            "Run: python src/analysis_pipeline.py"
        )

    df = pd.read_csv(DATA_PATH)
    engine = create_db_engine()
    table_name = "customer_analytics"
    schema = "public"

    table_exists = inspect(engine).has_table(table_name, schema=schema)

    if table_exists:
        # TRUNCATE keeps dependent views intact, unlike if_exists='replace'.
        with engine.begin() as connection:
            connection.execute(
                text(f'TRUNCATE TABLE {schema}.{table_name};')
            )
        write_mode = "append"
    else:
        write_mode = "fail"

    df.to_sql(
        name=table_name,
        con=engine,
        schema=schema,
        if_exists=write_mode,
        index=False,
        chunksize=1000,
        method="multi",
    )

    view_sql = VIEW_SQL_PATH.read_text(encoding="utf-8")
    with engine.begin() as connection:
        connection.exec_driver_sql(view_sql)
        row_count = connection.execute(
            text(f"SELECT COUNT(*) FROM {schema}.{table_name};")
        ).scalar_one()

    print(f"Loaded {row_count:,} rows into {schema}.{table_name}.")
    print("View public.retention_queue is ready.")


if __name__ == "__main__":
    main()
