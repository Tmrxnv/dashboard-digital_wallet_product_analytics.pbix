from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


AGE_BINS = [0, 25, 35, 45, 55, 65, float("inf")]
AGE_LABELS = ["До 25", "26-35", "36-45", "46-55", "56-65", "66+"]

INACTIVITY_BINS = [-1, 7, 30, 60, float("inf")]
INACTIVITY_LABELS = ["Active", "Engaged", "At Risk", "Dormant"]


def load_data(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found: {path}\n"
            "Place digital_wallet_ltv_dataset.csv in data/raw/."
        )
    return pd.read_csv(path)


def validate_data(df: pd.DataFrame) -> None:
    required_columns = {
        "Customer_ID",
        "Age",
        "Location",
        "Income_Level",
        "Total_Transactions",
        "Total_Spent",
        "Active_Days",
        "Last_Transaction_Days_Ago",
        "Cashback_Received",
        "Referral_Count",
        "App_Usage_Frequency",
        "Preferred_Payment_Method",
        "Support_Tickets_Raised",
        "Issue_Resolution_Time",
        "Customer_Satisfaction_Score",
        "LTV",
    }

    missing = sorted(required_columns - set(df.columns))
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    duplicate_ids = int(df["Customer_ID"].duplicated().sum())
    if duplicate_ids:
        raise ValueError(f"Found {duplicate_ids} duplicate Customer_ID values.")


def add_features(df: pd.DataFrame) -> pd.DataFrame:
    result = df.copy()

    result["Age_Group"] = pd.cut(
        result["Age"],
        bins=AGE_BINS,
        labels=AGE_LABELS,
        include_lowest=True,
    )

    result["Inactivity_Risk"] = pd.cut(
        result["Last_Transaction_Days_Ago"],
        bins=INACTIVITY_BINS,
        labels=INACTIVITY_LABELS,
    )

    result["LTV_Tier"] = pd.qcut(
        result["LTV"],
        q=4,
        labels=["Low", "Medium", "High", "Very High"],
    )

    return result


def assign_rfm_segment(row: pd.Series) -> str:
    r = row["R_Score"]
    f = row["F_Score"]
    m = row["M_Score"]

    if r >= 3 and f >= 3 and m >= 3:
        return "Champions"
    if r <= 2 and (f >= 3 or m >= 3):
        return "High Value at Risk"
    if r >= 3 and f >= 2:
        return "Loyal"
    if r >= 3 and f == 1:
        return "Promising"
    if r <= 2 and f <= 2 and m <= 2:
        return "Hibernating"
    return "Needs Attention"


def add_rfm_segments(df: pd.DataFrame) -> pd.DataFrame:
    result = df.copy()

    result["R_Score"] = pd.qcut(
        result["Last_Transaction_Days_Ago"].rank(method="first"),
        q=4,
        labels=[4, 3, 2, 1],
    ).astype(int)

    result["F_Score"] = pd.qcut(
        result["Total_Transactions"].rank(method="first"),
        q=4,
        labels=[1, 2, 3, 4],
    ).astype(int)

    result["M_Score"] = pd.qcut(
        result["Total_Spent"].rank(method="first"),
        q=4,
        labels=[1, 2, 3, 4],
    ).astype(int)

    result["RFM_Code"] = (
        result["R_Score"].astype(str)
        + result["F_Score"].astype(str)
        + result["M_Score"].astype(str)
    )
    result["RFM_Total"] = (
        result["R_Score"] + result["F_Score"] + result["M_Score"]
    )
    result["RFM_Segment"] = result.apply(assign_rfm_segment, axis=1)

    return result


def build_retention_queue(df: pd.DataFrame) -> pd.DataFrame:
    queue = df[df["RFM_Segment"] == "High Value at Risk"].copy()

    queue["Priority_Score"] = (
        queue["LTV"].rank(pct=True) * 0.5
        + queue["Total_Transactions"].rank(pct=True) * 0.3
        + queue["Last_Transaction_Days_Ago"].rank(pct=True) * 0.2
    )

    queue["Priority_Level"] = pd.qcut(
        queue["Priority_Score"].rank(method="first"),
        q=4,
        labels=["Low", "Medium", "High", "Critical"],
    )

    action_mapping = {
        "Critical": "Персональное предложение и прямой контакт",
        "High": "Повышенный кешбэк или бонус за возвращение",
        "Medium": "Персональная push- или email-кампания",
        "Low": "Автоматическое напоминание о продукте",
    }
    queue["Recommended_Action"] = (
        queue["Priority_Level"].astype(str).map(action_mapping)
    )

    return queue.sort_values("Priority_Score", ascending=False)


def build_rfm_summary(df: pd.DataFrame) -> pd.DataFrame:
    summary = (
        df.groupby("RFM_Segment")
        .agg(
            Customers=("Customer_ID", "nunique"),
            Average_LTV=("LTV", "mean"),
            Total_LTV=("LTV", "sum"),
            Average_Transactions=("Total_Transactions", "mean"),
            Average_Spent=("Total_Spent", "mean"),
            Average_Recency=("Last_Transaction_Days_Ago", "mean"),
        )
        .round(2)
        .sort_values("Total_LTV", ascending=False)
        .reset_index()
    )

    summary["Customer_Share_Pct"] = (
        summary["Customers"] / summary["Customers"].sum() * 100
    ).round(2)
    summary["LTV_Share_Pct"] = (
        summary["Total_LTV"] / summary["Total_LTV"].sum() * 100
    ).round(2)

    return summary


def save_charts(df: pd.DataFrame, output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)

    segment_counts = df["RFM_Segment"].value_counts().sort_values()
    plt.figure(figsize=(10, 6))
    segment_counts.plot(kind="barh")
    plt.title("Количество клиентов по RFM-сегментам")
    plt.xlabel("Количество клиентов")
    plt.ylabel("Сегмент")
    plt.tight_layout()
    plt.savefig(output_dir / "customers_by_rfm_segment.png", dpi=200)
    plt.close()

    ltv_by_segment = (
        df.groupby("RFM_Segment")["LTV"].sum().sort_values(ascending=False)
    )
    plt.figure(figsize=(10, 6))
    ltv_by_segment.plot(kind="bar")
    plt.title("Общий LTV по RFM-сегментам")
    plt.xlabel("RFM-сегмент")
    plt.ylabel("Общий LTV")
    plt.xticks(rotation=25, ha="right")
    plt.tight_layout()
    plt.savefig(output_dir / "ltv_by_rfm_segment.png", dpi=200)
    plt.close()


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Digital wallet customer and product analytics pipeline."
    )
    parser.add_argument(
        "--input",
        type=Path,
        default=Path("data/raw/digital_wallet_ltv_dataset.csv"),
    )
    parser.add_argument(
        "--processed-dir",
        type=Path,
        default=Path("data/processed"),
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("outputs"),
    )
    args = parser.parse_args()

    df = load_data(args.input)
    validate_data(df)

    customer_analytics = add_rfm_segments(add_features(df))
    retention_queue = build_retention_queue(customer_analytics)
    rfm_summary = build_rfm_summary(customer_analytics)

    args.processed_dir.mkdir(parents=True, exist_ok=True)
    args.output_dir.mkdir(parents=True, exist_ok=True)

    customer_analytics.to_csv(
        args.processed_dir / "digital_wallet_customer_segments.csv",
        index=False,
    )
    retention_queue.to_csv(
        args.processed_dir / "retention_queue.csv",
        index=False,
    )
    rfm_summary.to_csv(args.output_dir / "rfm_summary.csv", index=False)
    save_charts(customer_analytics, args.output_dir)

    print(f"Customers: {customer_analytics['Customer_ID'].nunique():,}")
    print(f"Rows exported: {len(customer_analytics):,}")
    print(f"Retention queue: {len(retention_queue):,}")


if __name__ == "__main__":
    main()
