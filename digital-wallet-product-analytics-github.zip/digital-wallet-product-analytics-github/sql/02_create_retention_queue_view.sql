CREATE OR REPLACE VIEW public.retention_queue AS
WITH customer_scores AS (
    SELECT
        "Customer_ID",
        "LTV",
        "Total_Transactions",
        "Total_Spent",
        "Last_Transaction_Days_Ago",
        "App_Usage_Frequency",
        "Preferred_Payment_Method",
        "Customer_Satisfaction_Score",
        PERCENT_RANK() OVER (ORDER BY "LTV") AS ltv_percentile,
        PERCENT_RANK() OVER (
            ORDER BY "Total_Transactions"
        ) AS transactions_percentile,
        PERCENT_RANK() OVER (
            ORDER BY "Last_Transaction_Days_Ago"
        ) AS recency_percentile
    FROM public.customer_analytics
    WHERE "RFM_Segment" = 'High Value at Risk'
),
priority_scores AS (
    SELECT
        *,
        (
            ltv_percentile * 0.5
            + transactions_percentile * 0.3
            + recency_percentile * 0.2
        ) AS priority_score
    FROM customer_scores
),
priority_groups AS (
    SELECT
        *,
        NTILE(4) OVER (ORDER BY priority_score) AS priority_bucket
    FROM priority_scores
)
SELECT
    "Customer_ID",
    "LTV",
    "Total_Transactions",
    "Total_Spent",
    "Last_Transaction_Days_Ago",
    "App_Usage_Frequency",
    "Preferred_Payment_Method",
    "Customer_Satisfaction_Score",
    ROUND(priority_score::numeric, 4) AS priority_score,
    CASE priority_bucket
        WHEN 4 THEN 'Critical'
        WHEN 3 THEN 'High'
        WHEN 2 THEN 'Medium'
        WHEN 1 THEN 'Low'
    END AS priority_level,
    CASE priority_bucket
        WHEN 4 THEN 'Персональное предложение и прямой контакт'
        WHEN 3 THEN 'Повышенный кешбэк или бонус за возвращение'
        WHEN 2 THEN 'Персональная push- или email-кампания'
        WHEN 1 THEN 'Автоматическое напоминание о продукте'
    END AS recommended_action
FROM priority_groups;
