-- Digital Wallet Product Analytics
-- PostgreSQL analytical queries
-- Monetary values are expressed in dataset units because the source
-- dataset does not specify a currency.

-- 1. Data checks
SELECT current_database();

SELECT
    COUNT(*) AS rows,
    COUNT(DISTINCT "Customer_ID") AS unique_customers,
    COUNT(*) FILTER (WHERE "Age_Group" IS NULL) AS blank_age_groups
FROM public.customer_analytics;

SELECT *
FROM public.customer_analytics
LIMIT 5;

-- 2. Overall KPIs
SELECT
    COUNT(DISTINCT "Customer_ID") AS customers,
    ROUND(AVG("LTV")::numeric, 2) AS average_ltv,
    ROUND(SUM("LTV")::numeric, 2) AS total_ltv,
    ROUND(AVG("Total_Transactions")::numeric, 2) AS average_transactions,
    ROUND(AVG("Total_Spent")::numeric, 2) AS average_spent,
    ROUND(AVG("Customer_Satisfaction_Score")::numeric, 2)
        AS average_satisfaction,
    ROUND(AVG("Last_Transaction_Days_Ago")::numeric, 2)
        AS average_recency
FROM public.customer_analytics;

-- 3. RFM segment performance
SELECT
    "RFM_Segment",
    COUNT(DISTINCT "Customer_ID") AS customers,
    ROUND(AVG("LTV")::numeric, 2) AS average_ltv,
    ROUND(SUM("LTV")::numeric, 2) AS total_ltv,
    ROUND(AVG("Total_Transactions")::numeric, 2)
        AS average_transactions,
    ROUND(AVG("Last_Transaction_Days_Ago")::numeric, 2)
        AS average_recency
FROM public.customer_analytics
GROUP BY "RFM_Segment"
ORDER BY total_ltv DESC;

-- 4. Highest-LTV customers in the at-risk segment
SELECT
    "Customer_ID",
    "LTV",
    "Total_Transactions",
    "Last_Transaction_Days_Ago",
    "App_Usage_Frequency",
    "Preferred_Payment_Method"
FROM public.customer_analytics
WHERE "RFM_Segment" = 'High Value at Risk'
ORDER BY "LTV" DESC
LIMIT 20;

-- 5. Retention priority summary
SELECT
    priority_level,
    COUNT(*) AS customers,
    ROUND(AVG("LTV")::numeric, 2) AS average_ltv,
    ROUND(SUM("LTV")::numeric, 2) AS total_ltv,
    ROUND(AVG("Last_Transaction_Days_Ago")::numeric, 2)
        AS average_recency
FROM public.retention_queue
GROUP BY priority_level
ORDER BY
    CASE priority_level
        WHEN 'Critical' THEN 1
        WHEN 'High' THEN 2
        WHEN 'Medium' THEN 3
        WHEN 'Low' THEN 4
    END;
