# Analysis report

## Executive summary

The project analyses a synthetic digital-wallet customer dataset with 7,000 unique customers. Python is used for data quality checks, feature engineering, RFM segmentation and retention prioritisation. PostgreSQL stores the processed customer table and exposes a retention queue through a SQL view. Power BI presents the final dashboard.

## Core KPIs

| Metric | Result |
|---|---:|
| Customers | 7,000 |
| Average LTV | 511,919.72 |
| Total LTV | 3,583,438,017.89 |
| Average transactions | 501.22 |
| Average satisfaction | 5.48 |
| Average days since last transaction | 183.85 |

Monetary values are dataset units because the source does not specify a currency.

## RFM findings

- **High Value at Risk:** 2,208 customers, 31.54% of the base and 43.83% of total LTV.
- **Champions:** 1,291 customers, 18.44% of the base and 34.76% of total LTV.
- Together these two segments represent **49.98% of customers** and **78.59% of total LTV**.
- Champions average 761 transactions and 93 days since the last operation.
- High Value at Risk customers average 673 transactions but about 275 days since the last operation.

## Retention queue

The High Value at Risk segment is ranked using:

- 50% LTV percentile;
- 30% transaction-frequency percentile;
- 20% recency percentile.

The **Critical** group contains 552 customers with average LTV of 1,258,798.36 and total LTV of approximately 694.86 million dataset units.

## Product observations

- LTV is almost perfectly correlated with Total Spent (`r = 0.999949`).
- Total Transactions has a moderate positive correlation with LTV (`r = 0.650863`).
- Differences in average LTV by payment method, app-usage frequency, income and location are small.
- Support, cashback, referral and satisfaction fields have weak standalone correlation with LTV.

## Interpretation limits

- The dataset is synthetic.
- `Inactivity_Risk` is a rule-based proxy, not confirmed churn.
- Recency differences across RFM segments are partly mechanical because recency is used to build those segments.
- A model predicting LTV from Total Spent would suffer from target leakage.
- The analysis is descriptive and does not establish causality.
