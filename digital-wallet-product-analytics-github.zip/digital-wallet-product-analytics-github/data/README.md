# Data

The source file is not committed to the repository.

Place the synthetic Kaggle dataset here:

```text
data/raw/digital_wallet_ltv_dataset.csv
```

Then run:

```bash
python src/analysis_pipeline.py
```

Generated files:

```text
data/processed/digital_wallet_customer_segments.csv
data/processed/retention_queue.csv
```

The original dataset URL was not included in the supplied materials, so the repository does not invent or guess a source link.
